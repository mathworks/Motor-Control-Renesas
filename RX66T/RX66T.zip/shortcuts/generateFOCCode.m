% Copyright 2024 The MathWorks, Inc.

StartUp;
EnterParameters;
slbuild ('FOCCurrentControl');
slbuild ('FOCSpeedControl');
slbuild ('ConfigParams');

currentPath = pwd;
projHandle = matlab.project.rootProject;
rootPath = projHandle.RootFolder;
cd (rootPath)
disp(" ");
disp(" ");
disp(" ");
disp(" ");
disp("### Copying generated code to csPlus folder")
copyfile code/FOCCurrentControl_ert_rtw/FOCCurrentControl.c csPlusProject\MotorControlDemo\genCode
copyfile code/FOCCurrentControl_ert_rtw/FOCCurrentControl.h csPlusProject\MotorControlDemo\genCode
copyfile code/FOCCurrentControl_ert_rtw/FOCCurrentControl_private.h csPlusProject\MotorControlDemo\genCode
copyfile code/FOCCurrentControl_ert_rtw/FOCCurrentControl_types.h csPlusProject\MotorControlDemo\genCode
copyfile code/FOCCurrentControl_ert_rtw/FOCCurrentControl_data.c csPlusProject\MotorControlDemo\genCode
copyfile code/FOCCurrentControl_ert_rtw/rtwtypes.h csPlusProject\MotorControlDemo\genCode
copyfile code/FOCCurrentControl_ert_rtw/rt_defines.h csPlusProject\MotorControlDemo\genCode

copyfile code/FOCSpeedControl_ert_rtw/FOCSpeedControl.c csPlusProject\MotorControlDemo\genCode
copyfile code/FOCSpeedControl_ert_rtw/FOCSpeedControl.h csPlusProject\MotorControlDemo\genCode
copyfile code/FOCSpeedControl_ert_rtw/FOCSpeedControl_types.h csPlusProject\MotorControlDemo\genCode

copyfile code/ConfigParams_ert_rtw/ConfigParameters.c csPlusProject\MotorControlDemo\genCode
copyfile code/ConfigParams_ert_rtw/ConfigParameters.h csPlusProject\MotorControlDemo\genCode
copyfile code/ConfigParams_ert_rtw/ConfigParams_types.h csPlusProject\MotorControlDemo\genCode

copyfile code/ConfigParams_ert_rtw/ConfigParams.c csPlusProject\MotorControlDemo\genCode
copyfile code/ConfigParams_ert_rtw/ConfigParams.h csPlusProject\MotorControlDemo\genCode

cd (currentPath)

clear projHandle rootPath currentPath temp
disp(" ");
disp(" ");
disp(" ");
disp(" ");
disp("### Code generated successful !")