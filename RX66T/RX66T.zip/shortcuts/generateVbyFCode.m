% Copyright 2024 The MathWorks, Inc.

StartUp;
slbuild ('VbyFApplication');
slbuild ('ConfigParams');

currentPath = pwd;
projHandle = matlab.project.rootProject;
rootPath = projHandle.RootFolder;
cd (rootPath)
disp(" ");
disp(" ");
disp(" ");
disp(" ");
disp("### Copying generated code to csPlus folder")
copyfile code/VbyFApplication_ert_rtw/VbyFApplication.c csPlusProject\MotorControlDemo\genCode
copyfile code/VbyFApplication_ert_rtw/VbyFApplication.h csPlusProject\MotorControlDemo\genCode
copyfile code/VbyFApplication_ert_rtw/VbyFApplication_types.h csPlusProject\MotorControlDemo\genCode
copyfile code/VbyFApplication_ert_rtw/VbyFApplication_private.h csPlusProject\MotorControlDemo\genCode
copyfile code/VbyFApplication_ert_rtw/rtwtypes.h csPlusProject\MotorControlDemo\genCode
copyfile code/VbyFApplication_ert_rtw/VbyFApplication_data.c csPlusProject\MotorControlDemo\genCode

copyfile code/ConfigParams_ert_rtw/ConfigParameters.c csPlusProject\MotorControlDemo\genCode
copyfile code/ConfigParams_ert_rtw/ConfigParameters.h csPlusProject\MotorControlDemo\genCode
copyfile code/ConfigParams_ert_rtw/ConfigParams_types.h csPlusProject\MotorControlDemo\genCode

copyfile code/ConfigParams_ert_rtw/ConfigParams.c csPlusProject\MotorControlDemo\genCode
copyfile code/ConfigParams_ert_rtw/ConfigParams.h csPlusProject\MotorControlDemo\genCode

cd (currentPath)

clear projHandle rootPath currentPath temp

disp(" ");
disp(" ");
disp(" ");
disp(" ");
disp("### Code generated successful !")
