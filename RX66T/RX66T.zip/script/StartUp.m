% Copyright 2024 The MathWorks, Inc.

dataType = 'single';
