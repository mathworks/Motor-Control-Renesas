% Copyright 2024 The MathWorks, Inc.

clear dataType pmsmCopy PU_SystemCopy sensor Ts_SerialOut TsCopy TsSpeedCopy;