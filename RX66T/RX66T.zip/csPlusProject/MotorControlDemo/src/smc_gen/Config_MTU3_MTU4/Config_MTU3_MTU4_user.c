/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products.
* No other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED
* OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY
* LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE FOR ANY DIRECT,
* INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR
* ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability 
* of this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2022 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name        : Config_MTU3_MTU4_user.c
* Component Version: 1.1.0
* Device(s)        : R5F566TEAxFP
* Description      : This file implements device driver for Config_MTU3_MTU4.
***********************************************************************************************************************/

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
/* Start user code for pragma. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_cg_macrodriver.h"
#include "Config_MTU3_MTU4.h"
/* Start user code for include. Do not edit comment generated here */
#if CONTROLALGORITHM == OPENLOOPCONTROL
#include "VbyFApplication.h"
#endif

#if CONTROLALGORITHM == CLOSEDLOOPCONTROL
#include "FOCCurrentControl.h"
#include "FOCSpeedControl.h"
#endif
/* End user code. Do not edit comment generated here */
#include "r_cg_userdefine.h"

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
/* Start user code for global. Do not edit comment generated here */
#define OPENLOOPCONTROL 0
#define CLOSEDLOOPCONTROL 1

#define ENCODER 0
#define SENSORLESS 1

// Configure control strategy below
//#define CONTROLALGORITHM OPENLOOPCONTROL
#define CONTROLALGORITHM CLOSEDLOOPCONTROL

// Configure sensor below
//#define SENSORSELECTION ENCODER
#define SENSORSELECTION SENSORLESS


r_mtr_adc_tb ADCBuff;
uint16_t Da= 1620, Db = 1620, Dc = 1620;

unsigned char Enable = 0;

float SpeedRef_RPM = 0.0f;
float SpeedFb_RPM = 0.0f;
float SpeedRefFinal_PU = 0.0f;
uint16_t Iab[2] = {0,0};
uint16_t Iab_offset[2];
uint16_t QuadCounts;
uint16_t PWMCount = 0x0CA8U;
float Vabc_out[3] = {0.0f, 0.0f, 0.0f};


//#if CONTROLALGORITHM == CLOSEDLOOPCONTROL
float IdqRef[2] = {0,0};
float SpeedFb_PU = 0.0F;
unsigned char EnCl = 0;
float IqFb = 0.0F;
float SpeedRefIn_PU = 0.0F;
float Mode = 0.0f;
//#endif

/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
* Function Name: R_Config_MTU3_MTU4_Create_UserInit
* Description  : This function adds user code after initializing the MTU channel
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

void R_Config_MTU3_MTU4_Create_UserInit(void)
{
    /* Start user code for user init. Do not edit comment generated here */
#if CONTROLALGORITHM == OPENLOOPCONTROL
    VbyFApllication_initialize();
#endif

#if CONTROLALGORITHM == CLOSEDLOOPCONTROL
    FOCCurrentControl_initialize();
    SpeedControl_initialize();
#endif
    /* End user code. Do not edit comment generated here */
}

/***********************************************************************************************************************
* Function Name: r_Config_MTU3_MTU4_CrestInterrupt
* Description  : This function is TGIA3 interrupt service routine
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

#if FAST_INTERRUPT_VECTOR == VECT_PERIA_INTA223
#pragma interrupt r_Config_MTU3_MTU4_CrestInterrupt(vect=VECT(PERIA,INTA223),fint)
#else
#pragma interrupt r_Config_MTU3_MTU4_CrestInterrupt(vect=VECT(PERIA,INTA223))
#endif
static void r_Config_MTU3_MTU4_CrestInterrupt(void)
{
    /* Start user code for r_Config_MTU3_MTU4_CrestInterrupt-1. Do not edit comment generated here */
    /* End user code. Do not edit comment generated here */
    
    /* Start user code for r_Config_MTU3_MTU4_CrestInterrupt-2. Do not edit comment generated here */
    /* End user code. Do not edit comment generated here */
}

/***********************************************************************************************************************
* Function Name: r_Config_MTU3_MTU4_ad_interrupt
* Description  : This function is S12ADI interrupt service routine
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/

#if FAST_INTERRUPT_VECTOR == VECT_S12AD_S12ADI
#pragma interrupt r_Config_MTU3_MTU4_ad_interrupt(vect=VECT(S12AD,S12ADI),fint)
#else
#pragma interrupt r_Config_MTU3_MTU4_ad_interrupt(vect=VECT(S12AD,S12ADI))
#endif
static void r_Config_MTU3_MTU4_ad_interrupt(void)
{
    /* Start user code for r_Config_MTU3_MTU4_ad_interrupt-1. Do not edit comment generated here */
    R_Config_MTU3_MTU4_AdcGetConvVal(&ADCBuff);
    Iab[0] = ADCBuff.u2_iu_ad;
    Iab[1] = ADCBuff.u2_iv_ad;
    
    if (PORT8.PIDR.BIT.B0 != 0){
	    Enable =  0; }
    else {
	    Enable =  1;}
    
#if CONTROLALGORITHM == CLOSEDLOOPCONTROL
#if SENSORSELECTION == SENSORLESS
        // Speed range is limited from 10% pmsm.N_base to pmsm.N_base
        SpeedRefIn_PU = ((float) ADCBuff.u2_vdc_ad * 0.6f/4095.0f) + 0.4f;
#endif
#endif

#if CONTROLALGORITHM == OPENLOOPCONTROL
        // Set speed reference based on POT position (limited to 10% of rated speed in VbyF)
        SpeedRef_RPM = ((float)ADCBuff.u2_vdc_ad - 2048.0f)/2048.0f * pmsm.N_base * 0.3f;
        VbyFApllication_step(Enable, SpeedRef_RPM, QuadCounts, Vabc_out, &SpeedFb_RPM);
#endif

#if CONTROLALGORITHM == CLOSEDLOOPCONTROL
        // Closed loop current control step function
        FOCCurrentControl_step(Enable, IdqRef, SpeedRefFinal_PU, EnCl, Iab, QuadCounts,
                Vabc_out, &SpeedFb_PU, &IqFb, &Mode, Iab_offset);
		/* void FOCCurrentControl_step(boolean_T arg_Enable, real32_T arg_IdqRef_PU[2],
  real32_T arg_SpeedRef_PU, boolean_T arg_EnClIn, uint16_T arg_Iab_ADC[2],
  uint16_T arg_ENCCounts, real32_T arg_Vabc_PU[3], real32_T *arg_SpeedFb_PU,
  real32_T *arg_Iq, real32_T *arg_Mode, uint16_T arg_Out1[2])*/

        // Motor speed in RPM
        SpeedFb_RPM = SpeedFb_PU * pmsm.N_base;        
#endif
	Da = 4320 - (uint16_t)(PWMCount * Vabc_out[0]);
	Db = 4320 - (uint16_t)(PWMCount * Vabc_out[1]);
	Dc = 4320 - (uint16_t)(PWMCount * Vabc_out[2]);
	
	R_Config_MTU3_MTU4_UpdDuty(Da, Db, Dc);
    /* End user code. Do not edit comment generated here */
    
    /* Start user code for r_Config_MTU3_MTU4_ad_interrupt-2. Do not edit comment generated here */
    /* End user code. Do not edit comment generated here */
}

/* Start user code for adding. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
