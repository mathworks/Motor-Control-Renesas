/*
 * File: VbyFApplication.h
 *
 * Code generated for Simulink model 'VbyFApplication'.
 *
 * Model version                  : 2.14
 * Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
 * C/C++ source code generated on : Tue Jun  4 11:48:48 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Renesas->RX
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_VbyFApplication_h_
#define RTW_HEADER_VbyFApplication_h_
#ifndef VbyFApplication_COMMON_INCLUDES_
#define VbyFApplication_COMMON_INCLUDES_
#include "rtwtypes.h"
#endif                                 /* VbyFApplication_COMMON_INCLUDES_ */

#include "VbyFApplication_types.h"

/* Includes for objects with custom storage classes */
#include "ConfigParameters.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

/* Block signals (default storage) */
typedef struct {
  real32_T Input;                      /* '<S35>/Input' */
} B_VbyFApplication_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  real32_T UnitDelay_DSTATE;           /* '<S21>/Unit Delay' */
  real32_T RampGenerator_DSTATE;       /* '<S17>/Ramp Generator' */
  real32_T UnitDelay_DSTATE_b;         /* '<S23>/Unit Delay' */
  real32_T UnitDelay_DSTATE_h;         /* '<S10>/Unit Delay' */
  uint32_T Delay_DSTATE[87];           /* '<S4>/Delay' */
  uint32_T CircBufIdx;                 /* '<S4>/Delay' */
  uint16_T Delay3_DSTATE;              /* '<S7>/Delay3' */
  uint16_T UnitDelay_DSTATE_hn;        /* '<S7>/Unit Delay' */
  boolean_T Delay_DSTATE_e;            /* '<S34>/Delay' */
} DW_VbyFApplication_T;

/* Constant parameters (default storage) */
typedef struct {
  /* Computed Parameter: sine_table_values_Value
   * Referenced by: '<S27>/sine_table_values'
   */
  real32_T sine_table_values_Value[1002];
} ConstP_VbyFApplication_T;

/* Real-time Model Data Structure */
struct tag_RTM_VbyFApplication_T {
  const char_T * volatile errorStatus;
};

/* Block signals (default storage) */
extern B_VbyFApplication_T VbyFApplication_B;

/* Block states (default storage) */
extern DW_VbyFApplication_T VbyFApplication_DW;

/* Constant parameters (default storage) */
extern const ConstP_VbyFApplication_T VbyFApplication_ConstP;

/* Model entry point functions */
extern void VbyFApllication_initialize(void);
extern void VbyFApplication_terminate(void);

/* Customized model step function */
extern void VbyFApllication_step(boolean_T arg_Enable, real32_T arg_SpeedRef_RPM,
  uint16_T arg_ENCCounts, real32_T arg_Vabc_PU[3], real32_T *arg_SpeedFb);

/* Real-time Model object */
extern RT_MODEL_VbyFApplication_T *const VbyFApplication_M;

/*-
 * These blocks were eliminated from the model due to optimizations:
 *
 * Block '<S10>/Data Type Duplicate' : Unused code path elimination
 * Block '<S21>/Data Type Duplicate' : Unused code path elimination
 * Block '<S22>/Data Type Duplicate' : Unused code path elimination
 * Block '<S25>/Data Type Duplicate' : Unused code path elimination
 * Block '<S26>/Data Type Duplicate' : Unused code path elimination
 * Block '<S26>/Data Type Duplicate1' : Unused code path elimination
 * Block '<S27>/Data Type Duplicate' : Unused code path elimination
 * Block '<S27>/Data Type Propagation' : Unused code path elimination
 * Block '<S32>/Data Type Duplicate' : Unused code path elimination
 * Block '<S33>/Data Type Duplicate' : Unused code path elimination
 * Block '<S23>/Data Type Duplicate2' : Unused code path elimination
 * Block '<S27>/Get_FractionVal' : Eliminate redundant data type conversion
 * Block '<S28>/Offset' : Unused code path elimination
 * Block '<S28>/Unary_Minus' : Unused code path elimination
 */

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'VbyFApplication'
 * '<S1>'   : 'VbyFApplication/IIR Filter'
 * '<S2>'   : 'VbyFApplication/OutputScaling_Sim'
 * '<S3>'   : 'VbyFApplication/Quadrature Decoder'
 * '<S4>'   : 'VbyFApplication/Speed Measurement1'
 * '<S5>'   : 'VbyFApplication/SpeedRefToFreq'
 * '<S6>'   : 'VbyFApplication/VabcCalc'
 * '<S7>'   : 'VbyFApplication/Wrap Encoder Counts'
 * '<S8>'   : 'VbyFApplication/IIR Filter/IIR Filter'
 * '<S9>'   : 'VbyFApplication/IIR Filter/IIR Filter/Low-pass'
 * '<S10>'  : 'VbyFApplication/IIR Filter/IIR Filter/Low-pass/IIR Low Pass Filter'
 * '<S11>'  : 'VbyFApplication/Quadrature Decoder/DT_Handle'
 * '<S12>'  : 'VbyFApplication/Quadrature Decoder/PositionNoReset'
 * '<S13>'  : 'VbyFApplication/Quadrature Decoder/PositionResetAtIndex'
 * '<S14>'  : 'VbyFApplication/Quadrature Decoder/DT_Handle/floating-point'
 * '<S15>'  : 'VbyFApplication/Speed Measurement1/DT_Handle'
 * '<S16>'  : 'VbyFApplication/Speed Measurement1/DT_Handle/floating-point'
 * '<S17>'  : 'VbyFApplication/SpeedRefToFreq/Ramp Generator'
 * '<S18>'  : 'VbyFApplication/SpeedRefToFreq/Rate Limiter'
 * '<S19>'  : 'VbyFApplication/SpeedRefToFreq/Rate Limiter/IIR Filter'
 * '<S20>'  : 'VbyFApplication/SpeedRefToFreq/Rate Limiter/IIR Filter/Low-pass'
 * '<S21>'  : 'VbyFApplication/SpeedRefToFreq/Rate Limiter/IIR Filter/Low-pass/IIR Low Pass Filter'
 * '<S22>'  : 'VbyFApplication/VabcCalc/3-Phase Sine Voltage Generator'
 * '<S23>'  : 'VbyFApplication/VabcCalc/Position Generator'
 * '<S24>'  : 'VbyFApplication/VabcCalc/Saturate output to limits'
 * '<S25>'  : 'VbyFApplication/VabcCalc/3-Phase Sine Voltage Generator/Inverse Clarke Transform'
 * '<S26>'  : 'VbyFApplication/VabcCalc/3-Phase Sine Voltage Generator/Inverse Park Transform'
 * '<S27>'  : 'VbyFApplication/VabcCalc/3-Phase Sine Voltage Generator/Sine-Cosine Lookup'
 * '<S28>'  : 'VbyFApplication/VabcCalc/3-Phase Sine Voltage Generator/Inverse Park Transform/Switch_Axis'
 * '<S29>'  : 'VbyFApplication/VabcCalc/3-Phase Sine Voltage Generator/Sine-Cosine Lookup/Interpolation'
 * '<S30>'  : 'VbyFApplication/VabcCalc/3-Phase Sine Voltage Generator/Sine-Cosine Lookup/WrapUp'
 * '<S31>'  : 'VbyFApplication/VabcCalc/3-Phase Sine Voltage Generator/Sine-Cosine Lookup/WrapUp/Compare To Zero'
 * '<S32>'  : 'VbyFApplication/VabcCalc/3-Phase Sine Voltage Generator/Sine-Cosine Lookup/WrapUp/If Action Subsystem'
 * '<S33>'  : 'VbyFApplication/VabcCalc/3-Phase Sine Voltage Generator/Sine-Cosine Lookup/WrapUp/If Action Subsystem1'
 * '<S34>'  : 'VbyFApplication/VabcCalc/Position Generator/Accumulate'
 * '<S35>'  : 'VbyFApplication/VabcCalc/Position Generator/Accumulate/Subsystem'
 * '<S36>'  : 'VbyFApplication/Wrap Encoder Counts/If Action Subsystem'
 * '<S37>'  : 'VbyFApplication/Wrap Encoder Counts/If Action Subsystem1'
 * '<S38>'  : 'VbyFApplication/Wrap Encoder Counts/If Action Subsystem2'
 */
#endif                                 /* RTW_HEADER_VbyFApplication_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
