/*
 * File: ConfigParameters.c
 *
 * Code generated for Simulink model 'ConfigParams'.
 *
 * Model version                  : 2.3
 * Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
 * C/C++ source code generated on : Tue Jun  4 11:48:54 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Renesas->RX
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "ConfigParameters.h"
#include "rtwtypes.h"
#include "ConfigParams_types.h"

/* Exported data definition */

/* Definition for custom storage class: ExportToFile */
struct_DWWWf6N21VtITTqdrqSn0 PI_params = {
  40.5949402F,
  76709.1F,
  40.5949402F,
  76709.1F,
  0.201039284F,
  5.30838871F,
  2,
  20,
  2
} ;                                    /* Referenced by: '<S1>/Gain6' */

/* Kp_Id, Ki_Id, Kp_Iq, Ki_Iq, Kp_speed, Ki_speed */
real_T T_pwm = 5.0E-5;                 /* Referenced by: '<S1>/Gain2' */

/* PWM period */
real_T Ts = 5.0E-5;                    /* Referenced by: '<S1>/Gain' */

/* Current controller sample time */
real_T Ts_speed = 0.0005;              /* Referenced by: '<S1>/Gain1' */

/* Speed controller sample time */
struct_oY6dKmFq1LLuoQRnygmJDC inverter = {
  24.0F,
  12.5F,
  0.0033F,
  -1.0F
} ;                                    /* Referenced by: '<S1>/Gain4' */

/* Vdc, VoltPerCount, Max measurable current Peak to neutral, board resistance, AmpPerCount */
struct_r9EHaSmCTTtRygMQYOGDfH pmsm = {
  2.0F,
  8.5F,
  0.0045F,
  0.0045F,
  7.83F,
  2.8e-6F,
  8.0e-5F,
  0.0215845257F,
  0.42F,
  1000.0F,
  3500.0F,
  0.1F,
  0.4F,
  2266.0F,
  0.4F
} ;                                    /* Referenced by: '<S1>/Gain3' */

/* motor parameters */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
