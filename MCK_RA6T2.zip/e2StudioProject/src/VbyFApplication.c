/*
 * File: VbyFApplication.c
 *
 * Code generated for Simulink model 'VbyFApplication'.
 *
 * Model version                  : 2.12
 * Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
 * C/C++ source code generated on : Wed May 15 17:48:57 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "VbyFApplication.h"
#include "rtwtypes.h"
#include <math.h>
#include "rt_nonfinite.h"
#include "VbyFApplication_private.h"
#include "VbyFApplication_types.h"
#include <float.h>
#include "ConfigParameters.h"

/* Block signals (default storage) */
B_VbyFApplication_T VbyFApplication_B;

/* Block states (default storage) */
DW_VbyFApplication_T VbyFApplication_DW;

/* Real-time model */
static RT_MODEL_VbyFApplication_T VbyFApplication_M_;
RT_MODEL_VbyFApplication_T *const VbyFApplication_M = &VbyFApplication_M_;
real32_T rt_modf_snf(real32_T u0, real32_T u1)
{
  real32_T y;
  y = u0;
  if (u1 == 0.0F) {
    if (u0 == 0.0F) {
      y = u1;
    }
  } else if (rtIsNaNF(u0) || rtIsNaNF(u1) || rtIsInfF(u0)) {
    y = (rtNaNF);
  } else if (u0 == 0.0F) {
    y = 0.0F / u1;
  } else if (rtIsInfF(u1)) {
    if ((u1 < 0.0F) != (u0 < 0.0F)) {
      y = u1;
    }
  } else {
    boolean_T yEq;
    y = fmodf(u0, u1);
    yEq = (y == 0.0F);
    if ((!yEq) && (u1 > floorf(u1))) {
      real32_T q;
      q = fabsf(u0 / u1);
      yEq = !(fabsf(q - floorf(q + 0.5F)) > FLT_EPSILON * q);
    }

    if (yEq) {
      y = u1 * 0.0F;
    } else if ((u0 < 0.0F) != (u1 < 0.0F)) {
      y += u1;
    }
  }

  return y;
}

/* Model step function */
void VbyFApllication_step(boolean_T arg_Enable, real32_T arg_SpeedRef_RPM,
  uint16_T arg_ENCCounts, real32_T arg_Vabc_PU[3], real32_T *arg_SpeedFb)
{
  real32_T rtb_DTC;
  real32_T rtb_Product_m;
  real32_T rtb_Switch_j_idx_0;
  real32_T rtb_convert_pu;
  uint32_T rtb_PositionToCount;
  uint16_T rtb_Merge;

  /* Sum: '<S21>/Add1' incorporates:
   *  Constant: '<S21>/Filter_Constant'
   *  Constant: '<S21>/One'
   *  Gain: '<S5>/rpm2freq'
   *  Inport: '<Root>/SpeedRef_RPM'
   *  Product: '<S21>/Product'
   *  Product: '<S21>/Product1'
   *  UnitDelay: '<S21>/Unit Delay'
   */
  VbyFApplication_DW.UnitDelay_DSTATE = pmsm.p / 60.0F * arg_SpeedRef_RPM *
    0.0001F + 0.9999F * VbyFApplication_DW.UnitDelay_DSTATE;

  /* DiscreteIntegrator: '<S17>/Ramp Generator' incorporates:
   *  Inport: '<Root>/Enable'
   *  Logic: '<S17>/NOT'
   */
  if (!arg_Enable) {
    VbyFApplication_DW.RampGenerator_DSTATE = 0.0F;
  }

  if (VbyFApplication_DW.RampGenerator_DSTATE >= 1.0F) {
    VbyFApplication_DW.RampGenerator_DSTATE = 1.0F;
  } else if (VbyFApplication_DW.RampGenerator_DSTATE <= 0.0F) {
    VbyFApplication_DW.RampGenerator_DSTATE = 0.0F;
  }

  /* Product: '<S5>/Product' incorporates:
   *  DiscreteIntegrator: '<S17>/Ramp Generator'
   *  UnitDelay: '<S21>/Unit Delay'
   */
  rtb_Product_m = VbyFApplication_DW.UnitDelay_DSTATE *
    VbyFApplication_DW.RampGenerator_DSTATE;

  /* Outputs for Enabled SubSystem: '<S23>/Accumulate' incorporates:
   *  EnablePort: '<S34>/Enable'
   */
  /* Outputs for Enabled SubSystem: '<S34>/Subsystem' incorporates:
   *  EnablePort: '<S35>/Enable'
   */
  /* Delay: '<S34>/Delay' */
  if (VbyFApplication_DW.Delay_DSTATE_e) {
    /* SignalConversion generated from: '<S35>/Input' incorporates:
     *  Gain: '<S23>/scaleIn'
     *  Gain: '<S6>/position_increment'
     *  Gain: '<S6>/position_increment1'
     */
    VbyFApplication_B.Input = 6.28318548F * rtb_Product_m * (real32_T)Ts *
      0.159154937F;
  }

  /* End of Delay: '<S34>/Delay' */
  /* End of Outputs for SubSystem: '<S34>/Subsystem' */

  /* Sum: '<S34>/Add' incorporates:
   *  UnitDelay: '<S23>/Unit Delay'
   */
  rtb_DTC = VbyFApplication_B.Input + VbyFApplication_DW.UnitDelay_DSTATE_b;

  /* DataTypeConversion: '<S34>/Data Type Conversion' */
  rtb_Switch_j_idx_0 = floorf(rtb_DTC);
  if (rtIsNaNF(rtb_Switch_j_idx_0) || rtIsInfF(rtb_Switch_j_idx_0)) {
    rtb_Switch_j_idx_0 = 0.0F;
  } else {
    rtb_Switch_j_idx_0 = fmodf(rtb_Switch_j_idx_0, 65536.0F);
  }

  /* Sum: '<S34>/Add1' incorporates:
   *  DataTypeConversion: '<S34>/Data Type Conversion'
   *  DataTypeConversion: '<S34>/Data Type Conversion1'
   *  UnitDelay: '<S23>/Unit Delay'
   */
  VbyFApplication_DW.UnitDelay_DSTATE_b = rtb_DTC - (real32_T)
    (rtb_Switch_j_idx_0 < 0.0F ? (int32_T)(int16_T)-(int16_T)(uint16_T)
     -rtb_Switch_j_idx_0 : (int32_T)(int16_T)(uint16_T)rtb_Switch_j_idx_0);

  /* Update for Delay: '<S34>/Delay' incorporates:
   *  Constant: '<S34>/Constant'
   */
  VbyFApplication_DW.Delay_DSTATE_e = true;

  /* End of Outputs for SubSystem: '<S23>/Accumulate' */

  /* Gain: '<S30>/convert_pu' incorporates:
   *  Gain: '<S23>/scaleOut'
   *  UnitDelay: '<S23>/Unit Delay'
   */
  rtb_convert_pu = 6.28318548F * VbyFApplication_DW.UnitDelay_DSTATE_b *
    0.159154937F;

  /* If: '<S30>/If' incorporates:
   *  Constant: '<S31>/Constant'
   *  RelationalOperator: '<S31>/Compare'
   */
  if (rtb_convert_pu < 0.0F) {
    /* Outputs for IfAction SubSystem: '<S30>/If Action Subsystem' incorporates:
     *  ActionPort: '<S32>/Action Port'
     */
    /* DataTypeConversion: '<S32>/Convert_uint16' */
    rtb_Switch_j_idx_0 = floorf(rtb_convert_pu);
    if (rtIsInfF(rtb_Switch_j_idx_0)) {
      rtb_Switch_j_idx_0 = 0.0F;
    } else {
      rtb_Switch_j_idx_0 = fmodf(rtb_Switch_j_idx_0, 65536.0F);
    }

    /* Sum: '<S32>/Sum' incorporates:
     *  DataTypeConversion: '<S32>/Convert_back'
     *  DataTypeConversion: '<S32>/Convert_uint16'
     */
    rtb_convert_pu -= (real32_T)(rtb_Switch_j_idx_0 < 0.0F ? (int32_T)(int16_T)
      -(int16_T)(uint16_T)-rtb_Switch_j_idx_0 : (int32_T)(int16_T)(uint16_T)
      rtb_Switch_j_idx_0);

    /* End of Outputs for SubSystem: '<S30>/If Action Subsystem' */
  } else {
    /* Outputs for IfAction SubSystem: '<S30>/If Action Subsystem1' incorporates:
     *  ActionPort: '<S33>/Action Port'
     */
    /* DataTypeConversion: '<S33>/Convert_uint16' */
    rtb_Switch_j_idx_0 = truncf(rtb_convert_pu);
    if (rtIsNaNF(rtb_Switch_j_idx_0) || rtIsInfF(rtb_Switch_j_idx_0)) {
      rtb_Switch_j_idx_0 = 0.0F;
    } else {
      rtb_Switch_j_idx_0 = fmodf(rtb_Switch_j_idx_0, 65536.0F);
    }

    /* Sum: '<S33>/Sum' incorporates:
     *  DataTypeConversion: '<S33>/Convert_back'
     *  DataTypeConversion: '<S33>/Convert_uint16'
     */
    rtb_convert_pu -= (real32_T)(int16_T)(uint16_T)rtb_Switch_j_idx_0;

    /* End of Outputs for SubSystem: '<S30>/If Action Subsystem1' */
  }

  /* End of If: '<S30>/If' */

  /* Gain: '<S27>/indexing' */
  rtb_convert_pu *= 800.0F;

  /* DataTypeConversion: '<S27>/Get_Integer' */
  rtb_Switch_j_idx_0 = truncf(rtb_convert_pu);
  if (rtIsNaNF(rtb_Switch_j_idx_0) || rtIsInfF(rtb_Switch_j_idx_0)) {
    rtb_Switch_j_idx_0 = 0.0F;
  } else {
    rtb_Switch_j_idx_0 = fmodf(rtb_Switch_j_idx_0, 65536.0F);
  }

  rtb_Merge = (uint16_T)(rtb_Switch_j_idx_0 < 0.0F ? (int32_T)(uint16_T)
    -(int16_T)(uint16_T)-rtb_Switch_j_idx_0 : (int32_T)(uint16_T)
    rtb_Switch_j_idx_0);

  /* End of DataTypeConversion: '<S27>/Get_Integer' */

  /* Gain: '<S6>/Correction_Factor_sinePWM' incorporates:
   *  Abs: '<S6>/Abs'
   *  Gain: '<S6>/V-by-f'
   */
  rtb_Product_m = 1.0F / (3120.0F * pmsm.p / 60.0F) * fabsf(rtb_Product_m) *
    1.15470052F;

  /* Switch: '<S24>/Switch' incorporates:
   *  Constant: '<Root>/Constant'
   *  RelationalOperator: '<S24>/Relational Operator'
   */
  if (!(rtb_Product_m > pmsm.V_boost)) {
    rtb_Product_m = pmsm.V_boost;
  }

  /* Sum: '<S27>/Sum2' incorporates:
   *  DataTypeConversion: '<S27>/Data Type Conversion1'
   */
  rtb_DTC = rtb_convert_pu - (real32_T)rtb_Merge;

  /* Selector: '<S27>/Lookup' incorporates:
   *  Constant: '<S27>/sine_table_values'
   *  Sum: '<S27>/Sum'
   */
  rtb_Switch_j_idx_0 = VbyFApplication_ConstP.sine_table_values_Value[rtb_Merge];

  /* Sum: '<S29>/Sum4' incorporates:
   *  Constant: '<S27>/offset'
   *  Constant: '<S27>/sine_table_values'
   *  Product: '<S29>/Product'
   *  Selector: '<S27>/Lookup'
   *  Sum: '<S27>/Sum'
   *  Sum: '<S29>/Sum3'
   */
  rtb_convert_pu = (VbyFApplication_ConstP.sine_table_values_Value[(int32_T)
                    (rtb_Merge + 1U)] - rtb_Switch_j_idx_0) * rtb_DTC +
    rtb_Switch_j_idx_0;

  /* Selector: '<S27>/Lookup' incorporates:
   *  Constant: '<S27>/offset'
   *  Constant: '<S27>/sine_table_values'
   *  Sum: '<S27>/Sum'
   *  Sum: '<S29>/Sum5'
   */
  rtb_Switch_j_idx_0 = VbyFApplication_ConstP.sine_table_values_Value[(int32_T)
    (rtb_Merge + 200U)];

  /* Sum: '<S29>/Sum6' incorporates:
   *  Constant: '<S27>/offset'
   *  Constant: '<S27>/sine_table_values'
   *  Product: '<S29>/Product1'
   *  Selector: '<S27>/Lookup'
   *  Sum: '<S27>/Sum'
   *  Sum: '<S29>/Sum5'
   */
  rtb_DTC = (VbyFApplication_ConstP.sine_table_values_Value[(int32_T)(rtb_Merge
              + 201U)] - rtb_Switch_j_idx_0) * rtb_DTC + rtb_Switch_j_idx_0;

  /* Saturate: '<S24>/Saturation' incorporates:
   *  Switch: '<S24>/Switch'
   */
  if (rtb_Product_m > 0.95F) {
    rtb_Switch_j_idx_0 = 0.95F;
  } else if (rtb_Product_m < 0.0F) {
    rtb_Switch_j_idx_0 = 0.0F;
  } else {
    rtb_Switch_j_idx_0 = rtb_Product_m;
  }

  /* Outputs for Atomic SubSystem: '<S22>/Inverse Park Transform' */
  /* Switch: '<S28>/Switch' incorporates:
   *  Constant: '<S22>/Constant'
   *  Product: '<S26>/dcos'
   *  Product: '<S26>/qsin'
   *  Saturate: '<S24>/Saturation'
   *  Sum: '<S26>/sum_alpha'
   *  UnaryMinus: '<S22>/Unary Minus'
   */
  rtb_Switch_j_idx_0 = 0.0F * rtb_DTC - -rtb_Switch_j_idx_0 * rtb_convert_pu;

  /* End of Outputs for SubSystem: '<S22>/Inverse Park Transform' */

  /* Switch: '<S2>/Switch' incorporates:
   *  Inport: '<Root>/Enable'
   */
  if (arg_Enable) {
    /* Saturate: '<S24>/Saturation' incorporates:
     *  Switch: '<S24>/Switch'
     */
    if (rtb_Product_m > 0.95F) {
      rtb_Product_m = 0.95F;
    } else if (rtb_Product_m < 0.0F) {
      rtb_Product_m = 0.0F;
    }

    /* Outputs for Atomic SubSystem: '<S22>/Inverse Park Transform' */
    /* Gain: '<S25>/sqrt3_by_two' incorporates:
     *  Constant: '<S22>/Constant'
     *  Product: '<S26>/dsin'
     *  Product: '<S26>/qcos'
     *  Saturate: '<S24>/Saturation'
     *  Sum: '<S26>/sum_beta'
     *  UnaryMinus: '<S22>/Unary Minus'
     */
    rtb_Product_m = (-rtb_Product_m * rtb_DTC + 0.0F * rtb_convert_pu) *
      0.866025388F;

    /* Gain: '<S25>/one_by_two' incorporates:
     *  AlgorithmDescriptorDelegate generated from: '<S26>/a16'
     */
    rtb_convert_pu = 0.5F * rtb_Switch_j_idx_0;

    /* Outport: '<Root>/Vabc_PU' incorporates:
     *  AlgorithmDescriptorDelegate generated from: '<S26>/a16'
     *  Constant: '<S2>/Constant'
     *  Gain: '<S2>/One_by_Two'
     *  Sum: '<S25>/add_b'
     *  Sum: '<S25>/add_c'
     *  Sum: '<S2>/Sum'
     */
    arg_Vabc_PU[0] = 0.5F * rtb_Switch_j_idx_0 + 0.5F;

    /* End of Outputs for SubSystem: '<S22>/Inverse Park Transform' */
    arg_Vabc_PU[1] = (rtb_Product_m - rtb_convert_pu) * 0.5F + 0.5F;
    arg_Vabc_PU[2] = ((0.0F - rtb_convert_pu) - rtb_Product_m) * 0.5F + 0.5F;
  } else {
    /* Outport: '<Root>/Vabc_PU' incorporates:
     *  Constant: '<S2>/Constant1'
     */
    arg_Vabc_PU[0] = 0.5F;
    arg_Vabc_PU[1] = 0.5F;
    arg_Vabc_PU[2] = 0.5F;
  }

  /* End of Switch: '<S2>/Switch' */

  /* If: '<S7>/If' incorporates:
   *  Constant: '<S36>/Constant'
   *  Constant: '<S37>/Constant'
   *  Delay: '<S7>/Delay3'
   *  Inport: '<Root>/ENCCounts'
   *  Math: '<S7>/Math Function'
   *  Sum: '<S36>/Add'
   *  Sum: '<S37>/Add'
   *  UnitDelay: '<S7>/Unit Delay'
   */
  if ((arg_ENCCounts > 49151) && (VbyFApplication_DW.Delay3_DSTATE < 16384)) {
    /* Outputs for IfAction SubSystem: '<S7>/If Action Subsystem' incorporates:
     *  ActionPort: '<S36>/Action Port'
     */
    VbyFApplication_DW.UnitDelay_DSTATE_hn = (uint16_T)
      (VbyFApplication_DW.UnitDelay_DSTATE_hn + 2464U);

    /* End of Outputs for SubSystem: '<S7>/If Action Subsystem' */
  } else if ((VbyFApplication_DW.Delay3_DSTATE > 49151) && (arg_ENCCounts <
              16384)) {
    /* Outputs for IfAction SubSystem: '<S7>/If Action Subsystem1' incorporates:
     *  ActionPort: '<S37>/Action Port'
     */
    VbyFApplication_DW.UnitDelay_DSTATE_hn = (uint16_T)
      (VbyFApplication_DW.UnitDelay_DSTATE_hn + 1536U);

    /* End of Outputs for SubSystem: '<S7>/If Action Subsystem1' */
  }

  VbyFApplication_DW.UnitDelay_DSTATE_hn = (uint16_T)
    (VbyFApplication_DW.UnitDelay_DSTATE_hn % 4000);

  /* End of If: '<S7>/If' */

  /* Outputs for IfAction SubSystem: '<S3>/PositionResetAtIndex' incorporates:
   *  ActionPort: '<S13>/Action Port'
   */
  /* If: '<S3>/If1' incorporates:
   *  Constant: '<S7>/Constant2'
   *  DataTypeConversion: '<S14>/Data Type Conversion'
   *  DataTypeConversion: '<S7>/Data Type Conversion'
   *  Gain: '<S3>/PositionGain'
   *  Gain: '<S4>/PositionToCount'
   *  Inport: '<Root>/ENCCounts'
   *  Math: '<S7>/Math Function1'
   *  SignalConversion generated from: '<S13>/Count'
   *  Sum: '<S7>/Add'
   *  UnitDelay: '<S7>/Unit Delay'
   */
  rtb_PositionToCount = (uint32_T)fmodf(truncf((real32_T)(uint16_T)(int32_T)
    fmodf((real32_T)(int32_T)rt_modf_snf((real32_T)(arg_ENCCounts +
    VbyFApplication_DW.UnitDelay_DSTATE_hn), 4000.0F), 65536.0F) *
    0.00157079636F * 6.83563648E+8F), 4.2949673E+9F);

  /* End of Outputs for SubSystem: '<S3>/PositionResetAtIndex' */

  /* Sum: '<S10>/Add1' incorporates:
   *  Constant: '<S10>/Filter_Constant'
   *  Constant: '<S10>/One'
   *  DataTypeConversion: '<S16>/DTC'
   *  Delay: '<S4>/Delay'
   *  Gain: '<S4>/SpeedGain'
   *  Product: '<S10>/Product'
   *  Product: '<S10>/Product1'
   *  Sum: '<S4>/SpeedCount'
   *  UnitDelay: '<S10>/Unit Delay'
   */
  VbyFApplication_DW.UnitDelay_DSTATE_h = (real32_T)((int32_T)
    rtb_PositionToCount - (int32_T)
    VbyFApplication_DW.Delay_DSTATE[VbyFApplication_DW.CircBufIdx]) *
    4.50639936E-6F * 0.01F + 0.99F * VbyFApplication_DW.UnitDelay_DSTATE_h;

  /* Outport: '<Root>/SpeedFb' incorporates:
   *  UnitDelay: '<S10>/Unit Delay'
   */
  *arg_SpeedFb = VbyFApplication_DW.UnitDelay_DSTATE_h;

  /* Update for DiscreteIntegrator: '<S17>/Ramp Generator' incorporates:
   *  Constant: '<S17>/One'
   *  Constant: '<S5>/Ramp_Time (sec)'
   *  Gain: '<S17>/Sample_Time'
   *  Product: '<S17>/Divide'
   */
  VbyFApplication_DW.RampGenerator_DSTATE += (real32_T)Ts * 0.333333343F;
  if (VbyFApplication_DW.RampGenerator_DSTATE >= 1.0F) {
    VbyFApplication_DW.RampGenerator_DSTATE = 1.0F;
  } else if (VbyFApplication_DW.RampGenerator_DSTATE <= 0.0F) {
    VbyFApplication_DW.RampGenerator_DSTATE = 0.0F;
  }

  /* End of Update for DiscreteIntegrator: '<S17>/Ramp Generator' */

  /* Update for Delay: '<S7>/Delay3' incorporates:
   *  Inport: '<Root>/ENCCounts'
   */
  VbyFApplication_DW.Delay3_DSTATE = arg_ENCCounts;

  /* Update for Delay: '<S4>/Delay' */
  VbyFApplication_DW.Delay_DSTATE[VbyFApplication_DW.CircBufIdx] =
    rtb_PositionToCount;
  if (VbyFApplication_DW.CircBufIdx < 30U) {
    VbyFApplication_DW.CircBufIdx++;
  } else {
    VbyFApplication_DW.CircBufIdx = 0U;
  }

  /* End of Update for Delay: '<S4>/Delay' */
}

/* Model initialize function */
void VbyFApllication_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));
}

/* Model terminate function */
void VbyFApplication_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
