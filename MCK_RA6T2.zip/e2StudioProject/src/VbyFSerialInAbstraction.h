/*
 * Prerelease License - for engineering feedback and testing purposes
 * only. Not for sale.
 *
 * File: VbyFSerialInAbstraction.h
 *
 * Code generated for Simulink model 'VbyFSerialInAbstraction'.
 *
 * Model version                  : 1.3
 * Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
 * C/C++ source code generated on : Thu Feb 29 11:10:48 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_VbyFSerialInAbstraction_h_
#define RTW_HEADER_VbyFSerialInAbstraction_h_
#ifndef VbyFSerialInAbstraction_COMMON_INCLUDES_
#define VbyFSerialInAbstraction_COMMON_INCLUDES_
#include "rtwtypes.h"
#endif                            /* VbyFSerialInAbstraction_COMMON_INCLUDES_ */

#include "VbyFSerialInAbstraction_types.h"
#include <string.h>

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

/* Block signals (default storage) */
typedef struct {
  real32_T ByteUnpack;                 /* '<Root>/Byte Unpack' */
} B_VbyFSerialInAbstraction_T;

/* External inputs (root inport signals with default storage) */
typedef struct {
  uint8_T SCI_Data[8];                 /* '<Root>/SCI_Data' */
} ExtU_VbyFSerialInAbstraction_T;

/* Real-time Model Data Structure */
struct tag_RTM_VbyFSerialInAbstracti_T {
  const char_T * volatile errorStatus;
};

/* Block signals (default storage) */
extern B_VbyFSerialInAbstraction_T VbyFSerialInAbstraction_B;

/* External inputs (root inport signals with default storage) */
extern ExtU_VbyFSerialInAbstraction_T VbyFSerialInAbstraction_U;

/* Model entry point functions */
extern void SerialInAbstraction_initialize(void);
extern void VbyFSerialInAbstraction_terminate(void);

/* Customized model step function */
extern void SerialInAbstraction_step(uint8_T arg_SCI_Data[8], boolean_T
  *arg_Enable, real32_T *arg_SpeedRef, uint8_T *arg_DebugSel);

/* Real-time Model object */
extern RT_MODEL_VbyFSerialInAbstract_T *const VbyFSerialInAbstraction_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'VbyFSerialInAbstraction'
 */
#endif                               /* RTW_HEADER_VbyFSerialInAbstraction_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
