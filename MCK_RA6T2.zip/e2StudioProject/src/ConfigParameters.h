/*
 * File: ConfigParameters.h
 *
 * Code generated for Simulink model 'ConfigParams'.
 *
 * Model version                  : 2.2
 * Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
 * C/C++ source code generated on : Wed May 15 17:48:03 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_ConfigParameters_h_
#define RTW_HEADER_ConfigParameters_h_
#include "rtwtypes.h"
#include "ConfigParams_types.h"

/* Exported data declaration */

/* Declaration for custom storage class: ExportToFile */
extern struct_DWWWf6N21VtITTqdrqSn0 PI_params;/* Referenced by: '<S1>/Gain6' */

/* Kp_Id, Ki_Id, Kp_Iq, Ki_Iq, Kp_speed, Ki_speed */
extern real_T T_pwm;                   /* Referenced by: '<S1>/Gain2' */

/* PWM period */
extern real_T Ts;                      /* Referenced by: '<S1>/Gain' */

/* Current controller sample time */
extern real_T Ts_speed;                /* Referenced by: '<S1>/Gain1' */

/* Speed controller sample time */
extern struct_I5k2n9mWimERhc2OS6k9dF inverter;/* Referenced by: '<S1>/Gain4' */

/* Vdc, VoltPerCount, Max measurable current Peak to neutral, board resistance, AmpPerCount */
extern struct_hXFaRMdP3p9q6ruHP5AkdC pmsm;/* Referenced by: '<S1>/Gain3' */

/* motor parameters */
#endif                                 /* RTW_HEADER_ConfigParameters_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
