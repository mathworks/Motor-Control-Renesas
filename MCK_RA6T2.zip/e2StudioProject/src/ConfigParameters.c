/*
 * File: ConfigParameters.c
 *
 * Code generated for Simulink model 'ConfigParams'.
 *
 * Model version                  : 2.2
 * Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
 * C/C++ source code generated on : Wed May 15 17:48:03 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "ConfigParameters.h"
#include "rtwtypes.h"
#include "ConfigParams_types.h"

/* Exported data definition */

/* Definition for custom storage class: ExportToFile */
struct_DWWWf6N21VtITTqdrqSn0 PI_params = {
  1.48848116F,
  2242.54565F,
  1.48848116F,
  2242.54565F,
  0.39543727F,
  5.22070742F,
  2,
  20,
  2
} ;                                    /* Referenced by: '<S1>/Gain6' */

/* Kp_Id, Ki_Id, Kp_Iq, Ki_Iq, Kp_speed, Ki_speed */
real_T T_pwm = 5.0E-5;                 /* Referenced by: '<S1>/Gain2' */

/* PWM period */
real_T Ts = 0.0001;                    /* Referenced by: '<S1>/Gain' */

/* Current controller sample time */
real_T Ts_speed = 0.001;               /* Referenced by: '<S1>/Gain1' */

/* Speed controller sample time */
struct_I5k2n9mWimERhc2OS6k9dF inverter = {
  24.0F,
  8.25F,
  0.0033F
} ;                                    /* Referenced by: '<S1>/Gain4' */

/* Vdc, VoltPerCount, Max measurable current Peak to neutral, board resistance, AmpPerCount */
struct_hXFaRMdP3p9q6ruHP5AkdC pmsm = {
  4.0F,
  0.75F,
  0.0005F,
  0.0005F,
  7.0F,
  8.0e-6F,
  8.0e-5F,
  0.009648256F,
  1.6F,
  1000.0F,
  3500.0F,
  0.1F,
  0.15F,
  3120.0F
} ;                                    /* Referenced by: '<S1>/Gain3' */

/* motor parameters */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
