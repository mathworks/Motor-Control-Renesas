myDictionaryObj = Simulink.data.dictionary.open('motorControlData.sldd');
dDataSectObj = getSection(myDictionaryObj,'Design Data');

% Ts
tempData = getEntry(dDataSectObj, 'Ts');
temp = getValue(tempData);
if ~isequal(Ts,temp.Value)
    temp.Value = Ts;
    setValue(tempData,temp);
end

% Ts_speed
tempData = getEntry(dDataSectObj, 'Ts_speed');
temp = getValue(tempData);
if ~isequal(Ts_speed,temp.Value)
    temp.Value = Ts_speed;
    setValue(tempData,temp);
end

% Ts_motor
tempData = getEntry(dDataSectObj, 'Ts_motor');
temp = getValue(tempData);
if ~isequal(Ts_motor,temp.Value)
    temp.Value = Ts_motor;
    setValue(tempData,temp);
end

% PWM_frequency
tempData = getEntry(dDataSectObj, 'PWM_frequency');
temp = getValue(tempData);
if ~isequal(target.PWM_frequency,temp.Value)
    temp.Value = target.PWM_frequency;
    setValue(tempData,temp);
end

% target
tempData = getEntry(dDataSectObj, 'target');
temp = getValue(tempData);
if ~isequal(target.PWM_frequency, temp.Value.PWM_frequency)
    temp.Value.PWM_frequency = target.PWM_frequency;
    setValue(tempData,temp);
end

% inverter
tempData = getEntry(dDataSectObj, 'inverter');
temp = getValue(tempData);
if ~isequal(inverter.V_dc, temp.Value.V_dc)
    temp.Value.V_dc = single(inverter.V_dc);
    setValue(tempData,temp);
end
if ~isequal(inverter.ISenseMax, temp.Value.ISenseMax)
    temp.Value.ISenseMax = single(inverter.ISenseMax);
    setValue(tempData,temp);
end
if ~isequal(inverter.R_board, temp.Value.R_board)
    temp.Value.R_board = single(inverter.R_board);
    setValue(tempData,temp);
end

tempData = getEntry(dDataSectObj, 'pmsm');
temp = getValue(tempData);
if ~isequal(pmsm.p, temp.Value.p)
    temp.Value.p = single(pmsm.p);
    setValue(tempData,temp);
end
if ~isequal(pmsm.Rs, temp.Value.Rs)
    temp.Value.Rs = single(pmsm.Rs);
    setValue(tempData,temp);
end
if ~isequal(pmsm.Ld, temp.Value.Ld)
    temp.Value.Ld = single(pmsm.Ld);
    setValue(tempData,temp);
end
if ~isequal(pmsm.Lq, temp.Value.Lq)
    temp.Value.Lq = single(pmsm.Lq);
    setValue(tempData,temp);
end
if ~isequal(pmsm.Ke, temp.Value.Ke)
    temp.Value.Ke = single(pmsm.Ke);
    setValue(tempData,temp);
end
if ~isequal(pmsm.J, temp.Value.J)
    temp.Value.J = single(pmsm.J);
    setValue(tempData,temp);
end
if ~isequal(pmsm.B, temp.Value.B)
    temp.Value.B = single(pmsm.B);
    setValue(tempData,temp);
end
if ~isequal(pmsm.FluxPM, temp.Value.FluxPM)
    temp.Value.FluxPM = single(pmsm.FluxPM);
    setValue(tempData,temp);
end
if ~isequal(pmsm.I_rated, temp.Value.I_rated)
    temp.Value.I_rated = single(pmsm.I_rated);
    setValue(tempData,temp);
end
if ~isequal(pmsm.QEPSlits, temp.Value.QEPSlits)
    temp.Value.QEPSlits = single(pmsm.QEPSlits);
    setValue(tempData,temp);
end
if ~isequal(pmsm.N_rated, temp.Value.N_rated)
    temp.Value.N_rated = single(pmsm.N_rated);
    setValue(tempData,temp);
end
if ~isequal(pmsm.T_rated, temp.Value.T_rated)
    temp.Value.T_rated = single(pmsm.T_rated);
    setValue(tempData,temp);
end
if ~isequal(pmsm.V_boost, temp.Value.V_boost)
    temp.Value.V_boost = single(pmsm.V_boost);
    setValue(tempData,temp);
end
if ~isequal(pmsm.N_base, temp.Value.N_base)
    temp.Value.N_base = single(pmsm.N_base);
    setValue(tempData,temp);
end

tempData = getEntry(dDataSectObj, 'PI_params');
temp = getValue(tempData);
if ~isequal(PI_params.Kp_id, temp.Value.Kp_id)
    temp.Value.Kp_id = single(PI_params.Kp_id);
    setValue(tempData,temp);
end
if ~isequal(PI_params.Ki_id, temp.Value.Ki_id)
    temp.Value.Ki_id = single(PI_params.Ki_id);
    setValue(tempData,temp);
end
if ~isequal(PI_params.Kp_i, temp.Value.Kp_iq)
    temp.Value.Kp_iq = single(PI_params.Kp_i);
    setValue(tempData,temp);
end
if ~isequal(PI_params.Ki_i, temp.Value.Ki_iq)
    temp.Value.Ki_iq = single(PI_params.Ki_i);
    setValue(tempData,temp);
end
if ~isequal(PI_params.Kp_speed, temp.Value.Kp_speed)
    temp.Value.Kp_speed = single(PI_params.Kp_speed);
    setValue(tempData,temp);
end
if ~isequal(PI_params.Ki_speed, temp.Value.Ki_speed)
    temp.Value.Ki_speed = single(PI_params.Ki_speed);
    setValue(tempData,temp);
end

myDictionaryObj.close; % close the data dictionary handle
clear myDictionaryObj dDataSectObj temp tempData;