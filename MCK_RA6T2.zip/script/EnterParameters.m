%% Control loop frequencies
fCurrentControl         = 10e3;     % Hz
fSpeedControl           = fCurrentControl/10;      % Hz

target.PWM_frequency    = 10e3;     % Hz            % The frequency configuration must be done in driver code too

%% Inverter Parameters
inverter.V_dc           = 24;       % V
inverter.ISenseMax      = 8.25;     % A             % Maximum current sensed by inverter
inverter.R_board        = 0.0033;   % ohm           % Rds_ON + Rshunt/3

%% Motor Parameters
pmsm.p                  = 4;        %               % Pole pairs
pmsm.I_rated            = 1.6;      % A
pmsm.N_rated            = 3500;     % RPM
pmsm.T_rated            = 0.1;      % Nm
pmsm.QEPSlits           = 1000;     %               % Quadrature encoder slits 
pmsm.Rs                 = 0.75;     % ohm
pmsm.Ld                 = 0.5e-3;   % H
pmsm.Lq                 = 0.5e-3;   % H
pmsm.Ke                 = 7;        % Vpk_LL/kRPM
pmsm.J                  = 8e-6;     % Kg-m2
pmsm.B                  = 8e-5;     % Kg-m2/s 
pmsm.V_boost            = 0.15;     % PU volt

%% Sensor selection
sensor = 'EEMF';                    % 'Encoder' , 'EEMF'

%% Derived Parameters
T_pwm = 1/target.PWM_frequency;
Ts = 1/fCurrentControl;
Ts_speed = 1/fSpeedControl;
Ts_motor = Ts/2;

Ts_SerialOut = 0.1;                                 % Required only for UART

pmsm.FluxPM   = (pmsm.Ke)/(sqrt(3)*2*pi*1000*pmsm.p/60);
pmsm.N_base   = mcb_getBaseSpeed(pmsm,inverter);
PU_System     = mcb_SetPUSystem(pmsm,inverter);
PI_params     = mcb_SetControllerParameters(pmsm,inverter,PU_System,T_pwm,Ts,Ts_speed);

% Create copies for EEMF block as the parameters are not tunable
TsCopy = Ts;
TsSpeedCopy = Ts_speed;
pmsmCopy = pmsm;
PU_SystemCopy = PU_System;

updateDictionary;

% clear data from base workspace as model uses Data dictionary
clear fCurrentControl fSpeedControl inverter PI_params pmsm PU_System T_pwm target Ts Ts_motor Ts_speed;