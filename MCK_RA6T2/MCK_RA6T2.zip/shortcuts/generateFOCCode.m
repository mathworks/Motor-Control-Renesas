% Copyright 2024 The MathWorks, Inc.

%% Load the parameters
StartUp;
EnterParameters;

%% Generate code for referenced models
slbuild ('FOCCurrentControl');
slbuild ('FOCSpeedControl');
slbuild ('ConfigParams');

%% Move the generated code to e2studio folder for IDE integration
currentPath = pwd;
projHandle = matlab.project.rootProject;
rootPath = projHandle.RootFolder;
cd (rootPath)
disp(" ");
disp(" ");
disp(" ");
disp(" ");
disp("### Copying generated code to e2studio folder")
copyfile code/FOCCurrentControl_ert_rtw/FOCCurrentControl.c e2StudioProject/src
copyfile code/FOCCurrentControl_ert_rtw/FOCCurrentControl.h e2StudioProject/src
copyfile code/FOCCurrentControl_ert_rtw/FOCCurrentControl_private.h e2StudioProject/src
copyfile code/FOCCurrentControl_ert_rtw/FOCCurrentControl_types.h e2StudioProject/src
copyfile code/FOCCurrentControl_ert_rtw/FOCCurrentControl_data.c e2StudioProject/src
copyfile code/FOCCurrentControl_ert_rtw/rtwtypes.h e2StudioProject/src
copyfile code/FOCCurrentControl_ert_rtw/rt_defines.h e2StudioProject/src

try
copyfile code/FOCCurrentControl_ert_rtw/rt_nonfinite.c e2StudioProject/src
copyfile code/FOCCurrentControl_ert_rtw/rt_nonfinite.h e2StudioProject/src
catch
end

try
copyfile code/FOCCurrentControl_ert_rtw/rtGetNaN.c e2StudioProject/src
copyfile code/FOCCurrentControl_ert_rtw/rtGetNaN.h e2StudioProject/src
catch
end

try
copyfile code/FOCCurrentControl_ert_rtw/rtGetInf.c e2StudioProject/src
copyfile code/FOCCurrentControl_ert_rtw/rtGetInf.h e2StudioProject/src
catch
end

copyfile code/FOCSpeedControl_ert_rtw/FOCSpeedControl.c e2StudioProject/src
copyfile code/FOCSpeedControl_ert_rtw/FOCSpeedControl.h e2StudioProject/src
copyfile code/FOCSpeedControl_ert_rtw/FOCSpeedControl_types.h e2StudioProject/src

copyfile code/ConfigParams_ert_rtw/ConfigParameters.c e2StudioProject/src
copyfile code/ConfigParams_ert_rtw/ConfigParameters.h e2StudioProject/src
copyfile code/ConfigParams_ert_rtw/ConfigParams_types.h e2StudioProject/src

copyfile code/ConfigParams_ert_rtw/ConfigParams.c e2StudioProject/src
copyfile code/ConfigParams_ert_rtw/ConfigParams.h e2StudioProject/src

cd (currentPath)

clear projHandle rootPath currentPath temp
disp(" ");
disp(" ");
disp(" ");
disp(" ");
disp("### Code generated successful !")

%%EOF