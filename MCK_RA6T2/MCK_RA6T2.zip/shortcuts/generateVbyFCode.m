StartUp;
slbuild ('VbyFApplication');
slbuild ('ConfigParams');

currentPath = pwd;
projHandle = matlab.project.rootProject;
rootPath = projHandle.RootFolder;
cd (rootPath)
disp(" ");
disp(" ");
disp(" ");
disp(" ");
disp("### Copying generated code to e2studio folder")
copyfile code/VbyFApplication_ert_rtw/VbyFApplication.c e2StudioProject/src
copyfile code/VbyFApplication_ert_rtw/VbyFApplication.h e2StudioProject/src
copyfile code/VbyFApplication_ert_rtw/VbyFApplication_types.h e2StudioProject/src
copyfile code/VbyFApplication_ert_rtw/VbyFApplication_private.h e2StudioProject/src
copyfile code/VbyFApplication_ert_rtw/rtwtypes.h e2StudioProject/src
copyfile code/VbyFApplication_ert_rtw/rt_nonfinite.c e2StudioProject/src
copyfile code/VbyFApplication_ert_rtw/rt_nonfinite.h e2StudioProject/src
copyfile code/VbyFApplication_ert_rtw/rtGetNaN.c e2StudioProject/src
copyfile code/VbyFApplication_ert_rtw/rtGetNaN.h e2StudioProject/src
copyfile code/VbyFApplication_ert_rtw/rtGetInf.c e2StudioProject/src
copyfile code/VbyFApplication_ert_rtw/rtGetInf.h e2StudioProject/src
copyfile code/VbyFApplication_ert_rtw/VbyFApplication_data.c e2StudioProject/src

copyfile code/ConfigParams_ert_rtw/ConfigParameters.c e2StudioProject/src
copyfile code/ConfigParams_ert_rtw/ConfigParameters.h e2StudioProject/src
copyfile code/ConfigParams_ert_rtw/ConfigParams_types.h e2StudioProject/src

copyfile code/ConfigParams_ert_rtw/ConfigParams.c e2StudioProject/src
copyfile code/ConfigParams_ert_rtw/ConfigParams.h e2StudioProject/src

cd (currentPath)

clear projHandle rootPath currentPath temp

disp(" ");
disp(" ");
disp(" ");
disp(" ");
disp("### Code generated successful !")
