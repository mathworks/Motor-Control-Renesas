% Copyright 2024 The MathWorks, Inc.

open_system('SimFOCSpeedControl');