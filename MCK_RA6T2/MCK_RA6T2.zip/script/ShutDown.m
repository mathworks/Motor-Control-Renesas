% Copyright 2024 The MathWorks, Inc.

clear dataType;