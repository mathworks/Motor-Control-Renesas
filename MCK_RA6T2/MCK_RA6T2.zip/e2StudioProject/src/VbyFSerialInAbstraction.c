/*
 * Prerelease License - for engineering feedback and testing purposes
 * only. Not for sale.
 *
 * File: VbyFSerialInAbstraction.c
 *
 * Code generated for Simulink model 'VbyFSerialInAbstraction'.
 *
 * Model version                  : 1.3
 * Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
 * C/C++ source code generated on : Thu Feb 29 11:10:48 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "VbyFSerialInAbstraction.h"
#include "rtwtypes.h"

/* Block signals (default storage) */
B_VbyFSerialInAbstraction_T VbyFSerialInAbstraction_B;

/* External inputs (root inport signals with default storage) */
ExtU_VbyFSerialInAbstraction_T VbyFSerialInAbstraction_U;

/* Real-time model */
static RT_MODEL_VbyFSerialInAbstract_T VbyFSerialInAbstraction_M_;
RT_MODEL_VbyFSerialInAbstract_T *const VbyFSerialInAbstraction_M =
  &VbyFSerialInAbstraction_M_;

/* Model step function */
void SerialInAbstraction_step(uint8_T arg_SCI_Data[8], boolean_T *arg_Enable,
  real32_T *arg_SpeedRef, uint8_T *arg_DebugSel)
{
  /* Copy value for root inport '<Root>/SCI_Data' since it is accessed globally */
  {
    int32_T i;
    for (i = 0; i < 8; i++)
      VbyFSerialInAbstraction_U.SCI_Data[i] = arg_SCI_Data[i];
  }

  /* Outport: '<Root>/Enable' incorporates:
   *  DataTypeConversion: '<Root>/Data Type Conversion'
   *  Inport: '<Root>/SCI_Data'
   */
  *arg_Enable = (VbyFSerialInAbstraction_U.SCI_Data[4] != 0);

  /* S-Function (byte2any): '<Root>/Byte Unpack' incorporates:
   *  Inport: '<Root>/SCI_Data'
   */

  /* Unpack: <Root>/Byte Unpack */
  (void) memcpy(&VbyFSerialInAbstraction_B.ByteUnpack,
                &VbyFSerialInAbstraction_U.SCI_Data[0],
                4);

  /* Outport: '<Root>/SpeedRef' */
  *arg_SpeedRef = VbyFSerialInAbstraction_B.ByteUnpack;

  /* Outport: '<Root>/DebugSel' incorporates:
   *  Inport: '<Root>/SCI_Data'
   */
  *arg_DebugSel = VbyFSerialInAbstraction_U.SCI_Data[5];
}

/* Model initialize function */
void SerialInAbstraction_initialize(void)
{
  /* (no initialization code required) */
}

/* Model terminate function */
void VbyFSerialInAbstraction_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
