/*
 * Prerelease License - for engineering feedback and testing purposes
 * only. Not for sale.
 *
 * File: VbyFSerialOutAbstraction_types.h
 *
 * Code generated for Simulink model 'VbyFSerialOutAbstraction'.
 *
 * Model version                  : 1.0
 * Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
 * C/C++ source code generated on : Thu Feb 29 11:10:51 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_VbyFSerialOutAbstraction_types_h_
#define RTW_HEADER_VbyFSerialOutAbstraction_types_h_

/* Forward declaration for rtModel */
typedef struct tag_RTM_VbyFSerialOutAbstract_T RT_MODEL_VbyFSerialOutAbstrac_T;

#endif                        /* RTW_HEADER_VbyFSerialOutAbstraction_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
