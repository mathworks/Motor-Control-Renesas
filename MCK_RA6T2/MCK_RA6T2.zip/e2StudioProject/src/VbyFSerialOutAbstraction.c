/*
 * Prerelease License - for engineering feedback and testing purposes
 * only. Not for sale.
 *
 * File: VbyFSerialOutAbstraction.c
 *
 * Code generated for Simulink model 'VbyFSerialOutAbstraction'.
 *
 * Model version                  : 1.0
 * Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
 * C/C++ source code generated on : Thu Feb 29 11:10:51 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "VbyFSerialOutAbstraction.h"
#include "rtwtypes.h"

/* Real-time model */
static RT_MODEL_VbyFSerialOutAbstrac_T VbyFSerialOutAbstraction_M_;
RT_MODEL_VbyFSerialOutAbstrac_T *const VbyFSerialOutAbstraction_M =
  &VbyFSerialOutAbstraction_M_;

/* Model step function */
void SerialOutAbstraction_step(real32_T arg_DebugData[3], uint8_T arg_DebugSel,
  real32_T *arg_SCI_Out)
{
  /* MultiPortSwitch: '<Root>/Multiport Switch' incorporates:
   *  Inport: '<Root>/DebugSel'
   */
  switch (arg_DebugSel) {
   case 1:
    /* Outport: '<Root>/SCI_Out' incorporates:
     *  Inport: '<Root>/DebugData'
     */
    *arg_SCI_Out = arg_DebugData[0];
    break;

   case 2:
    /* Outport: '<Root>/SCI_Out' incorporates:
     *  Inport: '<Root>/DebugData'
     */
    *arg_SCI_Out = arg_DebugData[1];
    break;

   default:
    /* Outport: '<Root>/SCI_Out' incorporates:
     *  Inport: '<Root>/DebugData'
     */
    *arg_SCI_Out = arg_DebugData[2];
    break;
  }

  /* End of MultiPortSwitch: '<Root>/Multiport Switch' */
}

/* Model initialize function */
void SerialOutAbstraction_initialize(void)
{
  /* (no initialization code required) */
}

/* Model terminate function */
void VbyFSerialOutAbstraction_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
