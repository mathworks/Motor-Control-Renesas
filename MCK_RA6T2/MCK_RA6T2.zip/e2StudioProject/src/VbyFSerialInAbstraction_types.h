/*
 * Prerelease License - for engineering feedback and testing purposes
 * only. Not for sale.
 *
 * File: VbyFSerialInAbstraction_types.h
 *
 * Code generated for Simulink model 'VbyFSerialInAbstraction'.
 *
 * Model version                  : 1.3
 * Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
 * C/C++ source code generated on : Thu Feb 29 11:10:48 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_VbyFSerialInAbstraction_types_h_
#define RTW_HEADER_VbyFSerialInAbstraction_types_h_

/* Forward declaration for rtModel */
typedef struct tag_RTM_VbyFSerialInAbstracti_T RT_MODEL_VbyFSerialInAbstract_T;

#endif                         /* RTW_HEADER_VbyFSerialInAbstraction_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
