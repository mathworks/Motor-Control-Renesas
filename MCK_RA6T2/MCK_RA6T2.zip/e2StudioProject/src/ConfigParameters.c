/*
 * File: ConfigParameters.c
 *
 * Code generated for Simulink model 'ConfigParams'.
 *
 * Model version                  : 2.2
 * Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
 * C/C++ source code generated on : Thu May 30 19:30:52 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "ConfigParameters.h"
#include "rtwtypes.h"
#include "ConfigParams_types.h"

/* Exported data definition */

/* Definition for custom storage class: ExportToFile */
struct_DWWWf6N21VtITTqdrqSn0 PI_params = {
  1.48848116F,
  2242.54565F,
  1.48848116F,
  2242.54565F,
  0.39543727F,
  5.22070742F,
  2,
  20,
  2
} ;                                    /* Referenced by: '<S1>/Gain6' */

/* PI_params.Kp_id - Proportional gain for Id controller
   PI_params.Ki_id - Integral gain for Id controller
   PI_params.Kp_iq - Proportional gain for Id controller
   PI_params.Ki_iq - Integral gain for Iq controller
   PI_params.Kp_speed - Proportional gain for speed controller
   PI_params.Ki_speed - Integral gain for speed controller
   PI_params.delay_Currents - Delay in current measurement [sec]
   PI_params.delay_Speed - Delay in speed measurement [sec]
   PI_params.delay_Position - Delay in position measurement [sec] */
real_T T_pwm = 5.0E-5;                 /* Referenced by: '<S1>/Gain2' */

/* T_pwm - PWM period [sec] */
real_T Ts = 0.0001;                    /* Referenced by: '<S1>/Gain' */

/* Ts - Current controller sample time [sec] */
real_T Ts_speed = 0.001;               /* Referenced by: '<S1>/Gain1' */

/* Ts_speed - Speed controller sample time [sec] */
struct_I5k2n9mWimERhc2OS6k9dF inverter = {
  24.0F,
  8.25F,
  0.0033F
} ;                                    /* Referenced by: '<S1>/Gain4' */

/* inverter.V_dc - DC link voltage of the inverter
   inverter.ISenseMax - Maximum measurement current by the current measurement circuit
   inverter.R_board - Inverter board resistance */
struct_hXFaRMdP3p9q6ruHP5AkdC pmsm = {
  4.0F,
  0.75F,
  0.0005F,
  0.0005F,
  7.0F,
  8.0e-6F,
  8.0e-5F,
  0.009648256F,
  1.6F,
  1000.0F,
  3500.0F,
  0.1F,
  0.15F,
  3120.0F
} ;                                    /* Referenced by: '<S1>/Gain3' */

/* pmsm.P - Number of pole pairs
   pmsm.Rs - Stator resistance
   pmsm.Ld - D axis inductance
   pmsm.Lq - Q axis inductance
   pmsm.Ke - Back EMF constant
   pmsm.J - Inertia
   pmsm.B - Friction co-efficient
   pmsm.FluxPM - PM flux computed from Ke
   pmsm.I_rated - Rated motor current
   pmsm.QEPSlits - Number of QEP slits in quadrature encoder
   pmsm.N_rated - Rated motor speed
   pmsm.T_rated - Rated motor torque
   pmsm.V_boost - Minimum voltage to spin in open loop as a ratio of rated motor voltage
   pmsm.N_base - Base speed of the motor */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
