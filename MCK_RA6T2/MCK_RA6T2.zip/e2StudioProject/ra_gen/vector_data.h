/* generated vector header file - do not edit */
#ifndef VECTOR_DATA_H
#define VECTOR_DATA_H
#ifdef __cplusplus
        extern "C" {
        #endif
/* Number of interrupts allocated */
#ifndef VECTOR_DATA_IRQ_COUNT
#define VECTOR_DATA_IRQ_COUNT    (12)
#endif
/* ISR prototypes */
void sci_b_uart_rxi_isr(void);
void sci_b_uart_txi_isr(void);
void sci_b_uart_tei_isr(void);
void sci_b_uart_eri_isr(void);
void gpt_counter_overflow_isr(void);
void adc_b_calend0_isr(void);
void adc_b_calend1_isr(void);
void adc_b_adi0_isr(void);
void gpt_capture_a_isr(void);
void gpt_capture_b_isr(void);

#if __has_include("r_ioport.h")
        /* Vector table allocations */
        #define VECTOR_NUMBER_SCI9_RXI ((IRQn_Type) 0) /* SCI9 RXI (Received data full) */
        #define SCI9_RXI_IRQn          ((IRQn_Type) 0) /* SCI9 RXI (Received data full) */
        #define VECTOR_NUMBER_SCI9_TXI ((IRQn_Type) 1) /* SCI9 TXI (Transmit data empty) */
        #define SCI9_TXI_IRQn          ((IRQn_Type) 1) /* SCI9 TXI (Transmit data empty) */
        #define VECTOR_NUMBER_SCI9_TEI ((IRQn_Type) 2) /* SCI9 TEI (Transmit end) */
        #define SCI9_TEI_IRQn          ((IRQn_Type) 2) /* SCI9 TEI (Transmit end) */
        #define VECTOR_NUMBER_SCI9_ERI ((IRQn_Type) 3) /* SCI9 ERI (Receive error) */
        #define SCI9_ERI_IRQn          ((IRQn_Type) 3) /* SCI9 ERI (Receive error) */
        #define VECTOR_NUMBER_GPT4_COUNTER_OVERFLOW ((IRQn_Type) 4) /* GPT4 COUNTER OVERFLOW (Overflow) */
        #define GPT4_COUNTER_OVERFLOW_IRQn          ((IRQn_Type) 4) /* GPT4 COUNTER OVERFLOW (Overflow) */
        #define VECTOR_NUMBER_ADC12_CALEND0 ((IRQn_Type) 5) /* ADC0 CALEND0 (End of calibration of A/D converter unit 0) */
        #define ADC12_CALEND0_IRQn          ((IRQn_Type) 5) /* ADC0 CALEND0 (End of calibration of A/D converter unit 0) */
        #define VECTOR_NUMBER_ADC12_CALEND1 ((IRQn_Type) 6) /* ADC0 CALEND1 (End of calibration of A/D converter unit 1) */
        #define ADC12_CALEND1_IRQn          ((IRQn_Type) 6) /* ADC0 CALEND1 (End of calibration of A/D converter unit 1) */
        #define VECTOR_NUMBER_ADC12_ADI0 ((IRQn_Type) 7) /* ADC0 ADI0 (End of A/D scanning operation(Gr.0)) */
        #define ADC12_ADI0_IRQn          ((IRQn_Type) 7) /* ADC0 ADI0 (End of A/D scanning operation(Gr.0)) */
        #define VECTOR_NUMBER_GPT3_COUNTER_OVERFLOW ((IRQn_Type) 8) /* GPT3 COUNTER OVERFLOW (Overflow) */
        #define GPT3_COUNTER_OVERFLOW_IRQn          ((IRQn_Type) 8) /* GPT3 COUNTER OVERFLOW (Overflow) */
        #define VECTOR_NUMBER_GPT3_CAPTURE_COMPARE_A ((IRQn_Type) 9) /* GPT3 CAPTURE COMPARE A (Compare match A) */
        #define GPT3_CAPTURE_COMPARE_A_IRQn          ((IRQn_Type) 9) /* GPT3 CAPTURE COMPARE A (Compare match A) */
        #define VECTOR_NUMBER_GPT3_CAPTURE_COMPARE_B ((IRQn_Type) 10) /* GPT3 CAPTURE COMPARE B (Compare match B) */
        #define GPT3_CAPTURE_COMPARE_B_IRQn          ((IRQn_Type) 10) /* GPT3 CAPTURE COMPARE B (Compare match B) */
        #define VECTOR_NUMBER_GPT0_COUNTER_OVERFLOW ((IRQn_Type) 11) /* GPT0 COUNTER OVERFLOW (Overflow) */
        #define GPT0_COUNTER_OVERFLOW_IRQn          ((IRQn_Type) 11) /* GPT0 COUNTER OVERFLOW (Overflow) */
        #endif

#ifdef __cplusplus
        }
        #endif
#endif /* VECTOR_DATA_H */
